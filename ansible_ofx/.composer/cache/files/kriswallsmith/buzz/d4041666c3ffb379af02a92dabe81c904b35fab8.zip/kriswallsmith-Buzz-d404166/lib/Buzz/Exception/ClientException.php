<?php

namespace Buzz\Exception;

/**
 * Thrown whenever a client process fails.
 */
class ClientException extends RuntimeException
{
}
