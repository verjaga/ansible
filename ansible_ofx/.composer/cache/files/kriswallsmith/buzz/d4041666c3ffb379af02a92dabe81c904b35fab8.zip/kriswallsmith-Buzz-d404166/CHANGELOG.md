## 0.15 (June 25, 2015)

 * Moved cookie jar implementation from `FileGetContents` client to a browser
   listener
 * Added `DigestAuthListener`

## 0.14 (June 2, 2015)

 * Changed default HTTP protocol version to 1.1
 * Added verify host control to `AbstractClient`
