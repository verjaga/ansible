<?php

namespace Mapping\Fixture\Xml;

class LoggableWithEmbedded
{
    private $id;

    private $title;

    private $status;

    private $embedded;
}
