<?php

namespace Mapping\Fixture\Xml;

class Status
{
    private $id;

    private $title;
}
