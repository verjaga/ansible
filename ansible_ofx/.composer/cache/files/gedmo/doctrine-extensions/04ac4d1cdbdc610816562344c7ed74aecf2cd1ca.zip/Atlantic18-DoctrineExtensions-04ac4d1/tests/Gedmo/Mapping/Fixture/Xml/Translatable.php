<?php

namespace Mapping\Fixture\Xml;

class Translatable
{
    private $id;

    private $title;

    private $content;

    private $locale;

    private $author;

    private $views;
}
