<?php

namespace Mapping\Fixture\Yaml;

class SoftDeleteable
{
    private $id;

    private $deletedAt;
}
