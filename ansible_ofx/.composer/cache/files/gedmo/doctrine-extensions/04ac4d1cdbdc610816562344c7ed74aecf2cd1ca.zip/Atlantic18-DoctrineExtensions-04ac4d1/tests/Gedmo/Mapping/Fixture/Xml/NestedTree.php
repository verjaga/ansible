<?php

namespace Mapping\Fixture\Xml;

class NestedTree
{
    private $id;

    private $name;

    private $parent;

    private $root;

    private $level;

    private $left;

    private $right;
}
