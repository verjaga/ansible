<?php

namespace Mapping\Fixture\Xml;

class TranslatableWithEmbedded
{
    private $id;

    private $title;

    private $content;

    private $locale;

    private $author;

    private $views;

    private $embedded;
}
