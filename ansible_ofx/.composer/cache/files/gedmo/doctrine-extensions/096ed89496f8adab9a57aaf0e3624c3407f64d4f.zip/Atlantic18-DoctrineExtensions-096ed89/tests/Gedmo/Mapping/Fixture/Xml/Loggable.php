<?php

namespace Mapping\Fixture\Xml;

class Loggable
{
    private $id;

    private $title;

    private $status;
}
