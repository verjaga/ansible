<?php

namespace Mapping\Fixture\Yaml;

class Referenced
{
    private $id;

    private $referencer;
}