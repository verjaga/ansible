<?php

namespace Mapping\Fixture\Yaml;

class Sortable
{
    private $id;

    private $title;

    private $position;

    private $grouping;

    private $sortable_group;

    private $sortable_groups;
}
