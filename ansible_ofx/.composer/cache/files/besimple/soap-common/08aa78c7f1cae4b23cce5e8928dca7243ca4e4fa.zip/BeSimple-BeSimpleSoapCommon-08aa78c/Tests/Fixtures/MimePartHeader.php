<?php

namespace BeSimple\SoapCommon\Tests\Fixtures;

use BeSimple\SoapCommon\Mime\PartHeader;

class MimePartHeader extends PartHeader
{
}
