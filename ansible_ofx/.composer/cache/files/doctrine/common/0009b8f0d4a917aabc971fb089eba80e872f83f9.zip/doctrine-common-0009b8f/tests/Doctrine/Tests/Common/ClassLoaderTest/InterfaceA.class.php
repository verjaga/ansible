<?php

interface ClassLoaderTest_InterfaceA
{
}
