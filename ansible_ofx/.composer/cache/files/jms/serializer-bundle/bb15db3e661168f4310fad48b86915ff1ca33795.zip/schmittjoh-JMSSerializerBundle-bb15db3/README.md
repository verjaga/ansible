JMSSerializerBundle
===================

This bundle integrates the [serializer library](https://github.com/schmittjoh/serializer) into Symfony2.

Please open new issues or feature request which are related to the library on the new repository.

You can learn more about the bundle in its [documentation](http://jmsyst.com/bundles/JMSSerializerBundle).
