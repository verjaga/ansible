FormSerializer
==============

This library will let your serialize a FormView into a DOMElement.

There are several handlers for the jms/serializer library.

Bundle
======

```php
$bundles[] = new AdrienBrault\FormSerializer\Bundle\AdrienBraultFormSerializerBundle();
```
