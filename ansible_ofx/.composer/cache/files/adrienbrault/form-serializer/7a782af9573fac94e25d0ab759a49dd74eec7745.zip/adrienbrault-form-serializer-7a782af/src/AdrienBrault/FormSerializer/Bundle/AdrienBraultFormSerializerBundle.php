<?php

namespace AdrienBrault\FormSerializer\Bundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class AdrienBraultFormSerializerBundle extends Bundle
{

}
