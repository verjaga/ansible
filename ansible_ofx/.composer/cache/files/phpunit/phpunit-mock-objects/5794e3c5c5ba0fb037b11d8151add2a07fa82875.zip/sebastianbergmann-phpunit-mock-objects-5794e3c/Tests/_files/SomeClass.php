<?php
class SomeClass
{
    public function doSomething($a, $b)
    {
        return NULL;
    }

    public function doSomethingElse($c)
    {
        return NULL;
    }
}
