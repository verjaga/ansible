<?php 
namespace PayPal\PayPalAPI;
use PayPal\EBLBaseComponents\AbstractResponseType; 
/**
 * 
 */
class BMSetInventoryResponseType  extends AbstractResponseType  
  {


}
