<?php 
namespace PayPal\EnhancedDataTypes;
use PayPal\Core\PPXmlMessage;
/**
 * 
 */
class EnhancedInitiateRecoupRequestDetailsType  
   extends PPXmlMessage{


    
}
