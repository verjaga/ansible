jQuery Component
================

Shim repository for the [jQuery](http://jquery.com).

Package Managers
----------------

* [Bower](http://twitter.github.com/bower/): `jquery`
* [Component](https://github.com/component/component): `components/jquery`
* [Composer](http://packagist.org/packages/components/jquery): `components/jquery`
