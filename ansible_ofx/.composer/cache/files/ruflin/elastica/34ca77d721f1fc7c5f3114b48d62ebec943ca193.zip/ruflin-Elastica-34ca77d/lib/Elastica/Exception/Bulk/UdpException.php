<?php
namespace Elastica\Exception\Bulk;

use Elastica\Exception\BulkException;

class UdpException extends BulkException
{
}
