<?php
namespace Elastica\Test\Exception\Bulk;

use Elastica\Test\Exception\AbstractExceptionTest;

class ResponseExceptionTest extends AbstractExceptionTest
{
}
