<?php
namespace Elastica\Test\Exception;

class NotFoundExceptionTest extends AbstractExceptionTest
{
}
