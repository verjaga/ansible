<?php
namespace Elastica\Test\Aggregation;

use Elastica\Test\Base;

abstract class BaseAggregationTest extends Base
{
}
