<?php
namespace Elastica\Aggregation;

/**
 * Class Avg.
 *
 * @link http://www.elastic.co/guide/en/elasticsearch/reference/current/search-aggregations-metrics-avg-aggregation.html
 */
class Avg extends AbstractSimpleAggregation
{
}
