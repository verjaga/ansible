<?php
namespace Elastica\Aggregation;

/**
 * Class Stats.
 *
 * @link http://www.elastic.co/guide/en/elasticsearch/reference/current/search-aggregations-metrics-stats-aggregation.html
 */
class Stats extends AbstractSimpleAggregation
{
}
