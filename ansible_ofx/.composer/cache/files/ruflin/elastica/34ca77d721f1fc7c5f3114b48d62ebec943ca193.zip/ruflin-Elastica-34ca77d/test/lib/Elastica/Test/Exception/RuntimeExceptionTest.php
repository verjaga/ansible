<?php
namespace Elastica\Test\Exception;

class RuntimeExceptionTest extends AbstractExceptionTest
{
}
