<?php
namespace Elastica\Test\Exception;

class ElasticsearchExceptionTest extends AbstractExceptionTest
{
}
