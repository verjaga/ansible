<?php
namespace Elastica\Test\Exception;

class ConnectionExceptionTest extends AbstractExceptionTest
{
}
