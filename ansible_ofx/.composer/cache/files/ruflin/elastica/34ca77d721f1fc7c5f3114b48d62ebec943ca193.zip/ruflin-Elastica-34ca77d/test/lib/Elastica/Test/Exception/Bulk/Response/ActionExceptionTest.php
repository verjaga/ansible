<?php
namespace Elastica\Test\Exception\Bulk\Response;

use Elastica\Test\Exception\AbstractExceptionTest;

class ActionExceptionTest extends AbstractExceptionTest
{
}
