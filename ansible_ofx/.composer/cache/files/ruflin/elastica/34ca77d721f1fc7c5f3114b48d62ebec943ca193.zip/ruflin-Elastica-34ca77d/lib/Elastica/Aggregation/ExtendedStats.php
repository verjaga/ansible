<?php
namespace Elastica\Aggregation;

/**
 * Class ExtendedStats.
 *
 * @link http://www.elastic.co/guide/en/elasticsearch/reference/current/search-aggregations-metrics-extendedstats-aggregation.html
 */
class ExtendedStats extends AbstractSimpleAggregation
{
}
