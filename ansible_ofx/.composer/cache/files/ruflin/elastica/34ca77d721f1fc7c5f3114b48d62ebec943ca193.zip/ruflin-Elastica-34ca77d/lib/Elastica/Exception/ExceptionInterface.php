<?php
namespace Elastica\Exception;

/**
 * General Elastica exception interface.
 *
 * @author Nicolas Ruflin <spam@ruflin.com>
 */
interface ExceptionInterface
{
}
