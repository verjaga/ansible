<?php
namespace Elastica\Aggregation;

/**
 * Class Min.
 *
 * @link http://www.elastic.co/guide/en/elasticsearch/reference/current/search-aggregations-metrics-min-aggregation.html
 */
class Min extends AbstractSimpleAggregation
{
}
