<?php
namespace Elastica\Aggregation;

/**
 * Class GlobalAggregation.
 *
 * @link http://www.elastic.co/guide/en/elasticsearch/reference/current/search-aggregations-bucket-global-aggregation.html
 */
class GlobalAggregation extends AbstractAggregation
{
}
