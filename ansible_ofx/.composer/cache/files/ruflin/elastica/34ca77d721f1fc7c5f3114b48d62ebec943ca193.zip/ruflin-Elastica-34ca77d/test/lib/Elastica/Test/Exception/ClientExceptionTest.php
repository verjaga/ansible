<?php
namespace Elastica\Test\Exception;

class ClientExceptionTest extends AbstractExceptionTest
{
}
