<?php
namespace Elastica\Test\Exception;

class QueryBuilderExceptionTest extends AbstractExceptionTest
{
}
