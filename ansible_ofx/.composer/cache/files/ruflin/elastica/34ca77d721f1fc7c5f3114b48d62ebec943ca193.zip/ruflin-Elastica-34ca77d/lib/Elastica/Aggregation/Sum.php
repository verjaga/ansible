<?php
namespace Elastica\Aggregation;

/**
 * Class Sum.
 *
 * @link http://www.elastic.co/guide/en/elasticsearch/reference/current/search-aggregations-metrics-sum-aggregation.html
 */
class Sum extends AbstractSimpleAggregation
{
}
