<?php
namespace Elastica\Exception;

/**
 * Client exception.
 *
 * @author Nicolas Ruflin <spam@ruflin.com>
 */
class ClientException extends \RuntimeException implements ExceptionInterface
{
}
