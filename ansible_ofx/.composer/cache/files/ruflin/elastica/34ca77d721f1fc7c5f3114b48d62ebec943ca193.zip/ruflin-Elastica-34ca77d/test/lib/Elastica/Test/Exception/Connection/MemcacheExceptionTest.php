<?php
namespace Elastica\Test\Exception\Connection;

use Elastica\Test\Exception\AbstractExceptionTest;

class MemcacheExceptionTest extends AbstractExceptionTest
{
}
