<?php
namespace Elastica\Aggregation;

/**
 * Class Max.
 *
 * @link http://www.elastic.co/guide/en/elasticsearch/reference/current/search-aggregations-metrics-max-aggregation.html
 */
class Max extends AbstractSimpleAggregation
{
}
