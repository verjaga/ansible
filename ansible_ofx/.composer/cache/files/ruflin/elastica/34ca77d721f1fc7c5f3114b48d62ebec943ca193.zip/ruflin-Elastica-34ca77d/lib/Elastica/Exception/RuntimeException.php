<?php
namespace Elastica\Exception;

/**
 * Client exception.
 *
 * @author Mikhail Shamin <munk13@gmail.com>
 */
class RuntimeException extends \RuntimeException implements ExceptionInterface
{
}
