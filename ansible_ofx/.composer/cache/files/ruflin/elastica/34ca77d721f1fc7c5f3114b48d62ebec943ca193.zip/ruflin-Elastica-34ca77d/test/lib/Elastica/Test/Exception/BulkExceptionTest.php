<?php
namespace Elastica\Test\Exception;

class BulkExceptionTest extends AbstractExceptionTest
{
}
