<?php
namespace Elastica\Exception\Connection;

use Elastica\Exception\ConnectionException;

/**
 * Transport exception.
 *
 * @author Igor Denisenko <im.denisenko@yahoo.com>
 */
class MemcacheException extends ConnectionException
{
}
