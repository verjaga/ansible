<?php
namespace Elastica\Test\Exception\Connection;

use Elastica\Test\Exception\AbstractExceptionTest;

class HttpExceptionTest extends AbstractExceptionTest
{
}
