<?php
namespace Elastica\Test\Exception;

class JSONParseExceptionTest extends AbstractExceptionTest
{
}
