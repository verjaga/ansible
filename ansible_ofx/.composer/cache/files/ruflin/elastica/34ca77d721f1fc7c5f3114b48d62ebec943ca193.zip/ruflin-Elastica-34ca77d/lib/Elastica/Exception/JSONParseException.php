<?php
namespace Elastica\Exception;

/**
 * JSON Parse exception.
 */
class JSONParseException extends \RuntimeException implements ExceptionInterface
{
}
