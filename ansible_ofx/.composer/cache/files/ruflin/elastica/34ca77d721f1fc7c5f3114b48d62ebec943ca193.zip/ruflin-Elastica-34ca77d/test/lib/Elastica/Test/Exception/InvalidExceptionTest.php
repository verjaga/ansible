<?php
namespace Elastica\Test\Exception;

class InvalidExceptionTest extends AbstractExceptionTest
{
}
