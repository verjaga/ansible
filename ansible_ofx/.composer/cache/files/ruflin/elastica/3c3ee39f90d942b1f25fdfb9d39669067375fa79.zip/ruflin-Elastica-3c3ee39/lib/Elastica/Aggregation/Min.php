<?php

namespace Elastica\Aggregation;

/**
 * Class Min
 * @package Elastica\Aggregation
 * @link http://www.elasticsearch.org/guide/en/elasticsearch/reference/master/search-aggregations-metrics-min-aggregation.html
 */
class Min extends AbstractSimpleAggregation
{

} 