<?php

namespace Elastica\Aggregation;

/**
 * Class Max
 * @package Elastica\Aggregation
 * @link http://www.elasticsearch.org/guide/en/elasticsearch/reference/master/search-aggregations-metrics-max-aggregation.html
 */
class Max extends AbstractSimpleAggregation
{

} 