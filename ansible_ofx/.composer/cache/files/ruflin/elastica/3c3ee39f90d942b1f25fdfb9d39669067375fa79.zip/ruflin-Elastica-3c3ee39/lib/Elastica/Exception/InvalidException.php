<?php

namespace Elastica\Exception;

/**
 * Invalid exception
 *
 * @category Xodoa
 * @package Elastica
 * @author Nicolas Ruflin <spam@ruflin.com>
 */
class InvalidException extends \InvalidArgumentException implements ExceptionInterface
{
}
