<?php

namespace Elastica\Exception;

/**
 * Client exception
 *
 * @category Xodoa
 * @package Elastica
 * @author Mikhail Shamin <munk13@gmail.com>
 */
class RuntimeException extends \RuntimeException implements ExceptionInterface
{
}
