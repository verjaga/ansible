<?php

namespace FOS\ElasticaBundle;

use FOS\ElasticaBundle\Elastica\Index;

/**
 * @deprecated Use \FOS\ElasticaBundle\Elastica\TransformingIndex
 */
class DynamicIndex extends Index
{
}
