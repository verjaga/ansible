<?php

namespace FOS\ElasticaBundle;

use FOS\ElasticaBundle\Index\IndexManager as BaseIndexManager;

/**
 * @deprecated Use \FOS\ElasticaBundle\Index\IndexManager
 */
class IndexManager extends BaseIndexManager
{
}
