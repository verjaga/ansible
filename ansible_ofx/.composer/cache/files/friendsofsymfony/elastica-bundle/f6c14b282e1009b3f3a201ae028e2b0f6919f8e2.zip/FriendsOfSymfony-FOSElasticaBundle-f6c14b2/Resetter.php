<?php

namespace FOS\ElasticaBundle;

use FOS\ElasticaBundle\Index\Resetter as BaseResetter;

/**
 * @deprecated Use \FOS\ElasticaBundle\Index\Resetter
 */
class Resetter extends BaseResetter
{
}
