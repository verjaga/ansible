<?php

namespace FOS\ElasticaBundle;

use FOS\ElasticaBundle\Elastica\Client as BaseClient;

/**
 * @deprecated Use \FOS\ElasticaBundle\Elastica\LoggingClient
 */
class Client extends BaseClient
{
}
