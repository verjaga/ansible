<?php

namespace Sensio\Bundle\FrameworkExtraBundle\Tests\Templating\Fixture\Controller;

class OutOfBundleController
{
}
