SensioFrameworkExtraBundle
==========================

This bundle provides a way to configure your controllers with annotations.

Read about it on its [official homepage](http://symfony.com/doc/current/bundles/SensioFrameworkExtraBundle/index.html).

As of v3.0.0 of the bundle, the release cycle is de-synchronized from the
framework's. It means you can just require "sensio/framework-extra-bundle":
"~3.0" in your composer.json and Composer will automatically pick the latest
version of the bundle that works with your current version of Symfony. The
minimum version of Symfony2 for this workflow is 2.3.
