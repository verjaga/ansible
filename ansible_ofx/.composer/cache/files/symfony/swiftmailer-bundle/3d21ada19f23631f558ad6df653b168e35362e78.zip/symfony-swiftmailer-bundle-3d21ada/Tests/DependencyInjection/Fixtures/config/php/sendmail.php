<?php
$container->loadFromExtension('swiftmailer', array(
    'transport'  => "sendmail",
));
