/**
 * This is a JavaScript test file.
 */
var foo = "bar";
