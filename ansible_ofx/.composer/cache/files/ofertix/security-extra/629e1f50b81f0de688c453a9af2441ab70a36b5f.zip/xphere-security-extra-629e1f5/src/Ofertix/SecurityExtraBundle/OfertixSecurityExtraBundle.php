<?php

namespace Ofertix\SecurityExtraBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OfertixSecurityExtraBundle extends Bundle
{
}
