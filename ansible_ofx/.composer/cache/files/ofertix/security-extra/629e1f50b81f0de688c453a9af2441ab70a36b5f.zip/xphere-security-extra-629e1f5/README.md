Ofertix\SecurityExtraBundle
===========================

Provides @Role and @Param annotations for securing controllers.
It supports whole class securing or per-action configuration.

Usage: https://gist.github.com/xphere/6917202
